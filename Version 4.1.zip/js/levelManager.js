import { CONFIG } from './config.js';

export class LevelManager {
    constructor() {
        this.reset()
    }

    getCurrentLevel(){
        return this.level;
    }

    getCurrentTimeLimit(){
        return this.timeLimit
    }

    getCurrentTargetScore(){
        return this.targetScore
    }

    getMaxLevel(){
        return this.maxLevel
    }

    advanceLevel() {
        if (this.level < this.maxLevel) {
            this.level++;
            this.timeLimit = Math.max(30, CONFIG.timeLimit - (this.level - 1) * 5);
            this.targetScore = 10 + (this.level - 1) * 50;
        }
    }

    reset() {
        this.level = 1;
        this.timeLimit = CONFIG.timeLimit;
        this.targetScore = 10;
        this.maxLevel = 5;        
    }
}